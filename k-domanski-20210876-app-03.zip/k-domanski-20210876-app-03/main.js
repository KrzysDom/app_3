// Progressive Enhancement (SW supported)
// if ('serviceWorker' in navigator) {
  if (navigator.serviceWorker) {

    // Register the SW
    navigator.serviceWorker.register('/sw.js').then((registration) => {
  
    }).catch(console.log);
  }
  

function myFunction() {
    var x = document.getElementById("myLinks");
    if (x.style.display === "block") {
      x.style.display = "none";
    } else {
      x.style.display = "block";
    }
  }


function load(){

  var url_string = window.location.href
    var url = new URL(url_string);
    var st = url.searchParams.get("search");
    console.log(">>"+st);
    if(st!=null){
      getJSON(st);
    }
}

  function computeBMI()
  {
      
      var height=Number(document.getElementById("height").value);
      var heightunits=document.getElementById("heightunits").value;
      var weight=Number(document.getElementById("weight").value);
      var weightunits=document.getElementById("weightunits").value;


      
      if (heightunits=="inches") height/=39.3700787;
      if (weightunits=="lb") weight/=2.20462;

      
      var BMI=weight/Math.pow(height,2);

     
      document.getElementById("output").innerText=Math.round(BMI*100)/100;

      var output =  Math.round(BMI*100)/100
      if (output<18.5)
      document.getElementById("comment").innerText = "Underweight";
    else   if (output>=18.5 && output<=25)
      document.getElementById("comment").innerText = "Normal";
   else   if (output>=25 && output<=30)
      document.getElementById("comment").innerText = "Overweight";
   else   if (output>30)
      document.getElementById("comment").innerText = "Obese";
      //document.getElementById("answer").value=output; 
  }

  //console.log($.param('brandName'));
  
  async function getJSON(st){
    
    

    // S9VrZnjlGjF2bav0uN2ROBRLeqFcgL8GIJnEgtc1
    //"https://api.nal.usda.gov/fdc/v1/foods/search?api_key=S9VrZnjlGjF2bav0uN2ROBRLeqFcgL8GIJnEgtc1&query="+st

    console.log("searchText >>>"+st+"<<<");

	  let myObject = await fetch("https://api.nal.usda.gov/fdc/v1/foods/search?api_key=S9VrZnjlGjF2bav0uN2ROBRLeqFcgL8GIJnEgtc1&query="+st);
	  //let myObject = await fetch("js/data.json");
	  let myJSON = await myObject.json();

    let myArray = myJSON.foods;

    console.log("myArray >>>"+myArray+"<<<");


			let str = '<hr />';
			for(let i=0; i<myArray.length ;i++){

        if(myArray[i].brandName!==undefined){
				  str += '<a href="details.html?id='+i+'&st='+st+'" class="list-group-item justify-content-between">';
          str += myArray[i].brandName
          str += '<span ><i class="fa fa-chevron-circle-right" aria-hidden="true"></i></span></a><br /><hr />';
        }
      }

			$("#results").html(str);
	  
	}

  // function getJSON(searchText){
	async function getJSONDetails(){

    var url_string = window.location.href
    var url = new URL(url_string);
    var id = url.searchParams.get("id");
    console.log(id);

    var url_string = window.location.href
    var url = new URL(url_string);
    var st = url.searchParams.get("st");
    console.log(st);

	  let myObject = await fetch("https://api.nal.usda.gov/fdc/v1/foods/search?api_key=S9VrZnjlGjF2bav0uN2ROBRLeqFcgL8GIJnEgtc1&query="+st);
	  let myJSON = await myObject.json();
	  let data =  myJSON.foods[id];
	  console.log(data);
	  console.log(data.brandName);
	  

	$("#name").html(data.brandName);
    $("#ingredients").html(data.ingredients);
    $("#cal").html(data.foodNutrients[3].value+"kcal per 100g");
    $("#carbs").html(data.foodNutrients[2].value+"g per 100g");
    $("#protein").html(data.foodNutrients[0].value+"g per 100g");
    $("#fat").html(data.foodNutrients[1].value +"g per 100g");
	}

